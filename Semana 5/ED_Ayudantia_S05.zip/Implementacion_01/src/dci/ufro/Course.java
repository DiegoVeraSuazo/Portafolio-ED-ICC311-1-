package dci.ufro;

public class Course {

    private int courseNo;

    public Course(int courseNo) {
        this.courseNo = courseNo;
    }

    public int getCourseNo() {
        return courseNo;
    }

    public void setCourseNo(int courseNo) {
        this.courseNo = courseNo;
    }
}
