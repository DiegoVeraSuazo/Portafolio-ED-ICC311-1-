package dci.ufro;

public enum ESemester {
    winter,
    summer;

    public String getESemester(){
        return this.name();
    }
}
