package dci.ufro;

public class AdministrativeEmployee extends Employee{

    public AdministrativeEmployee(int ssNO, String name, String email) {
        super(ssNO, name, email);
    }

}
