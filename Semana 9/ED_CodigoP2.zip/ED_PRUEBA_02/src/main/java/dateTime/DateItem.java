package dateTime;

public class DateItem {
    public String datetime;

    public DateItem(String date) {
        this.datetime = date;
    }

}
