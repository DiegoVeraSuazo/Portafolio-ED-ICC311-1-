package Supermercado.Modelo;

public interface Operaciones {

    void mostrar();

}
