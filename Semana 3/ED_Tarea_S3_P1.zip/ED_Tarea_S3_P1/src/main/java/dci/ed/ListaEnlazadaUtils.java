package dci.ed;


import java.util.Collections;
import java.util.*;
public class ListaEnlazadaUtils {

    public static void insertarOrdenado(LinkedList<Integer> lista, int valor) {
        /* Implementar método */
    }

    public static void removerValoresMaximos(LinkedList<String> list, int N) {

        /* Implementar método */
    }

    public static boolean contieneSubsecuencia(LinkedList<Integer> one, LinkedList<Integer> two) {
        /* Implementar método */
        return false; // modificar según conveniencia
    }
}
