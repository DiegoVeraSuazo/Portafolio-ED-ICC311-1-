public class Gato implements Comportamiento {

    Boolean catExist =  true;

    @Override
    public String hacerSonido() {
        return "miau miaaau";
    }



}
