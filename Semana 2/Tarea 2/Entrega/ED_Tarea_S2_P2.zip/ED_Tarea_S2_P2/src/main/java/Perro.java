public class Perro implements Comportamiento{

    boolean DogExist = true;

    @Override
    public String hacerSonido() {
        return "woof woof";
    }


}
