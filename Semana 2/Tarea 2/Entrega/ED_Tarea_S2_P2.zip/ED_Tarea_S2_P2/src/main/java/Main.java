public class Main {

    public static void main(String[] args) {

        Gato schrodinger = new Gato();
        Perro odi = new Perro();

        Boolean exist = true;

        if (schrodinger.catExist = exist){
            System.out.println("Schrodinger: "+schrodinger.hacerSonido());
            System.out.println("El gato empezo a comer");
            System.out.println(schrodinger.comer());
        } else {
            System.out.println(".....");
        }


        if (odi.DogExist = exist){
            System.out.println("Odi: "+odi.hacerSonido());
            System.out.println("El perro empezo a comer");
            System.out.println(odi.comer());
        } else {
            System.out.println(".....");
        }



    }


}
