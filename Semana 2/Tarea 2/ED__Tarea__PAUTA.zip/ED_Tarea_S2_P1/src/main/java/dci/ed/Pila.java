package dci.ed;

public class Pila {
    Nodo top = null;
    // agregar los elementos que permiten implementar una Pila

    /*
     *  Método que permite agregar un elemento desde el frente de la pila
     */
    public void push(int valor){
        Nodo nuevoNodo = new Nodo(valor);
        if(this.top == null){
           this.top = nuevoNodo;
        }else{
            Nodo auxiliar = this.top;
            this.top = nuevoNodo;
            this.top.siguiente = auxiliar;
        }
    }

    /*
     *  Método que permite eliminar un elemento desde el frente de la pila
     */
    public void pop(){
        if(this.top == null){
            throw new NullPointerException();
        }else{
            this.top = this.top.siguiente;
        }
    }
}
