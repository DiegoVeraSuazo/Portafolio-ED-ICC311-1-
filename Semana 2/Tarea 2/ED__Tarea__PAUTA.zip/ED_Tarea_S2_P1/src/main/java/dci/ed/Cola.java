package dci.ed;

public class Cola {

    Nodo front = null;
    Nodo rear = null;
    // agregar los elementos que permiten implementar una Cola
    /*
     *  Método que permite agregar al final de la rear
     */
    public void agregarEnCola(int valor){
        Nodo nuevoNodo = new Nodo(valor);
        if(this.front == null){
            this.front = nuevoNodo;
            this.rear = front;
        }else{
            this.rear.siguiente = nuevoNodo;
            this.rear = nuevoNodo;
        }
    }

    /*
     *  Método que permite remover desde el frente de la rear
     */
    public void removerDesdeFrente(){
        if(this.front == null) {
            throw new NullPointerException();
        }else{
            this.front = this.front.siguiente;
        }
    }

}
