package dci.ed;

public class ListaEnlazada {

    Nodo cabeza = null;
    Nodo cola = null;

    /*
     *  Método que permite si un valor particular
     *  existe en la Lista Enlazada
     */
    public boolean contiene(int valor){
        Nodo actual = cabeza;
        while(actual != null) {
            if(actual.valor==valor){
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    /*
     *  Método que permite obtener un valor determinado
     *  en una posición específica de una la Lista Enlazada
     */
    public int getPorIndice(int index){
        Nodo actual = cabeza;
        //agregar el if
        if(actual == null){
            throw new NullPointerException();
        }

        for (int i =0;i<index;i++){
            if (actual == null) {
                throw new IndexOutOfBoundsException();
            }
            actual = actual.siguiente;
        }
        return actual.valor;
    }

    /*
     *  Método que permite remover un valor
     *  desde el frente de una la Lista Enlazada
     */
    public void removerDesdeFrente(){
        if(cabeza != null) {
            if(cabeza.equals(cola)){
                this.cabeza = null;
                this.cola = null;
            }else {
                this.cabeza = cabeza.siguiente;
            }
        }else{
            throw new NullPointerException();
        }
    }

    /*
     *  Método que permite remover un valor
     *  desde la rear una la Lista Enlazada
     */
    public void removerDesdeCola(){
        Nodo actual = cabeza;
        if(actual == null){
            throw new NullPointerException();
        }

        if(cabeza.equals(cola)){
            cabeza = null;
            cola = null;
        }else {
            while (!actual.siguiente.equals(this.cola)) {
                actual = actual.siguiente;
            }
            this.cola = actual;
        }
    }

    /*
     *  Método que permite remover un valor determinado
     *  en una posición específica de una la Lista Enlazada
     */
    public void removerEnIndice(int index){
        if(index<0){//caso lista vacia
            throw new IndexOutOfBoundsException();
        }else if ( index == 0 || this.cabeza.equals(this.cola)) { //caso front y caso lista con 1 elemento
            removerDesdeFrente();
        }else{
            Nodo actual = this.cabeza;
            for (int i =0;i<index-2;i++){
                if ( actual == null ) {
                    throw new IndexOutOfBoundsException();
                }
                actual = actual.siguiente;
            }
            if ( actual.siguiente == null ) { //eliminar al final
                removerDesdeCola();
            } else { //caso con 3 o mas valores
                Nodo siguiente = actual.siguiente.siguiente;
                actual.siguiente = siguiente;
            }
        }
    }

    /*
     *  Método que permite agregar un elemento
     *  al frente de la Lista Enlazada
     */
    public void agregarFrente(int valor){
        // implementar
        Nodo nuevoNodo = new Nodo(valor);
        if(this.cabeza == null){
            cabeza = nuevoNodo;
            cola = nuevoNodo;
        }else {
            nuevoNodo.siguiente = cabeza;
            cabeza = nuevoNodo;
        }
    }

    /*
     *  Método que permite agregar un elemento
     *  al final la Lista Enlazada
     */
    public void agregarFinal(int valor){
        // implementar
        Nodo nuevoNodo = new Nodo(valor);
        if(this.cabeza == null){
            cabeza = nuevoNodo;
            cola = nuevoNodo;
        }else {
            cola.siguiente = nuevoNodo;
            cola = nuevoNodo;
        }
    }

    /*
     *  Método que permite agregar un elemento
     *  en un índice específico de la Lista Enlazada
     */
    public void agregarEnIndice(int index, int valor){
        Nodo nuevoNodo = new Nodo(valor);
        if(index<0){
            throw new IndexOutOfBoundsException();
        }else if ( index == 0) { // agregar en la front
            agregarFrente(valor);
        }else{
            Nodo actual = cabeza;
            for (int i =0;i<index-1;i++){
                if ( actual == null ) {
                    throw new IndexOutOfBoundsException();
                }
                actual = actual.siguiente;
            }
            if ( actual.siguiente == null ) { //añadir al final
                actual.siguiente = cola;
                cola = nuevoNodo;
            } else {
                nuevoNodo.siguiente = actual.siguiente;
                actual.siguiente = nuevoNodo;
            }
        }
    }

    /*
     *  Método que permite imprimir los elementos
     *  de la Lista Enlazada
     */
    public void imprimirLista(ListaEnlazada nombreLista){
        if(nombreLista.cabeza==null){
            System.out.print("[]");
        }else{
            Nodo actual = cabeza;
            String respuesta = "[";
            while(actual != null) {
                if(actual.siguiente != null) {
                    respuesta = respuesta + actual.valor + ",";
                }else{
                    respuesta = respuesta + actual.valor;
                }
                actual = actual.siguiente;
            }
            System.out.print(respuesta+"]");
        }
    }

}
