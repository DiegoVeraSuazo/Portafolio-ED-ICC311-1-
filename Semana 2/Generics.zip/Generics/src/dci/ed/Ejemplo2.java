package dci.ed;

import java.util.ArrayList;

public class Ejemplo2 {
    public static void main(String[] args) {
        ArrayList<Integer> arrayList2 = new ArrayList<Integer>();
        //ArrayList<int> arrayList3 = new ArrayList<int>();
    }


}
