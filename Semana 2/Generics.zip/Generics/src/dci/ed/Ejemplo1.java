package dci.ed;

import java.util.ArrayList;

public class Ejemplo1 {

    public static void main(String[] args) {
        int x = 5;
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(x);
        arrayList.add(4);
        System.out.println(arrayList);
    }
}
