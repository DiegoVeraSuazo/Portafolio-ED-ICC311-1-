package main;

import interfaz.Terminal;

public class main {

    public static void main(String[] args) {

        Terminal terminal = new Terminal();
        terminal.menu();

    }

}
