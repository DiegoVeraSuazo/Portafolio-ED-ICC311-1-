package ejemplo1;

public class Nodo {

    Juego juego;
    Nodo nodoDerecho;
    Nodo nodoIzquierdo;

    public Nodo(Juego juego) {
        this.juego = juego;
    }

}
