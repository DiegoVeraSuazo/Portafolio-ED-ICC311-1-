package ed.dci;

public class Nodo {
    int valor;
    Nodo siguiente = null;

    Nodo(int valor) {
        this.valor = valor;
    }
}